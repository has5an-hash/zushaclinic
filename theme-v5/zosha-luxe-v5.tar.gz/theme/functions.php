<?php
if (!defined('ABSPATH')) exit;
function zosha_v5_setup(){add_theme_support('title-tag');add_theme_support('post-thumbnails');add_theme_support('woocommerce');add_theme_support('html5',['search-form','gallery','caption','style','script']);register_nav_menus(['primary'=>'منوی اصلی']);}
add_action('after_setup_theme','zosha_v5_setup');
function zosha_v5_assets(){ $v=wp_get_theme()->get('Version'); wp_enqueue_style('zosha-v5',get_template_directory_uri().'/assets/css/main.css',[],$v); wp_enqueue_script('zosha-v5',get_template_directory_uri().'/assets/js/app.js',[],$v,true); }
add_action('wp_enqueue_scripts','zosha_v5_assets');
function zosha_media_url($key,$fallback=''){ $id=(int)get_option('zosha_media_'.$key,0); if($id){$url=wp_get_attachment_image_url($id,'full');if($url)return $url;} return $fallback; }
function zosha_img($key,$alt='',$class='',$fallback=''){ $url=zosha_media_url($key,$fallback);if(!$url)return '';return '<img src="'.esc_url($url).'" alt="'.esc_attr($alt).'" class="'.esc_attr($class).'" loading="lazy" decoding="async">'; }
function zosha_phone(){return '02122747895';} function zosha_mobile(){return '09125947829';} function zosha_instagram(){return 'https://instagram.com/zosha.clinic';}
add_filter('body_class',function($classes){$classes[]='zosha-v5';return $classes;});
