<?php if (!defined('ABSPATH')) exit; ?>
<!doctype html><html <?php language_attributes(); ?> dir="rtl"><head>
<meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#fbf6f2"><?php wp_head(); ?>
</head><body <?php body_class(); ?>><?php wp_body_open(); ?>
<div class="top-strip"><div class="shell"><span>کلینیک زیبایی و پوست زوشا · تجریش</span><a href="tel:<?php echo esc_attr(zosha_phone()); ?>">مشاوره تلفنی: <?php echo esc_html(zosha_phone()); ?></a></div></div>
<header class="site-header" id="siteHeader"><div class="shell header-inner">
<a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="زوشا"><span class="brand-mark">Z</span><span class="brand-lockup"><b>ZOSHA</b><small>BEAUTY CLINIC</small></span></a>
<nav class="main-nav" aria-label="منوی اصلی"><a href="<?php echo esc_url(home_url('/')); ?>">خانه</a><a href="<?php echo esc_url(home_url('/services/')); ?>">خدمات</a><a href="<?php echo esc_url(home_url('/portfolio/')); ?>">نمونه‌کارها</a><a href="<?php echo esc_url(home_url('/about/')); ?>">درباره ما</a><a href="<?php echo esc_url(home_url('/contact/')); ?>">تماس</a></nav>
<div class="header-actions"><a class="header-instagram" target="_blank" rel="noopener" href="<?php echo esc_url(zosha_instagram()); ?>">Instagram ↗</a><a class="btn header-book" href="<?php echo esc_url(home_url('/booking/')); ?>">رزرو وقت</a><button class="menu-button" aria-controls="mobileMenu" aria-expanded="false" aria-label="باز کردن منو"><i></i><i></i></button></div>
</div><div class="mobile-menu" id="mobileMenu"><a href="<?php echo esc_url(home_url('/')); ?>">خانه</a><a href="<?php echo esc_url(home_url('/services/')); ?>">خدمات</a><a href="<?php echo esc_url(home_url('/portfolio/')); ?>">نمونه‌کارها</a><a href="<?php echo esc_url(home_url('/about/')); ?>">درباره زوشا</a><a href="<?php echo esc_url(home_url('/contact/')); ?>">تماس</a><a class="btn btn-primary" href="<?php echo esc_url(home_url('/booking/')); ?>">رزرو مشاوره</a></div></header>
<main id="content">
