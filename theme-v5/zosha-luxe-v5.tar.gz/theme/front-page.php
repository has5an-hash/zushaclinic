<?php get_header();
$hero      = zosha_media_url('stock_facial2', zosha_media_url('stock_facial'));
$laser     = zosha_media_url('stock_laser2', zosha_media_url('stock_laser'));
$skin      = zosha_media_url('stock_skincare2', zosha_media_url('stock_spa'));
$detail    = zosha_media_url('stock_detail', zosha_media_url('stock_facial'));
$interior  = zosha_media_url('interior');
$ig        = zosha_media_url('instagram_grid');
$profile   = zosha_media_url('instagram_profile');
$gallery = array_values(array_filter([$hero,$skin,$laser,$interior,$detail,$ig]));
?>
<section class="hero-v5">
  <div class="hero-orb orb-a"></div><div class="hero-orb orb-b"></div>
  <div class="shell hero-v5-grid">
    <div class="hero-v5-copy reveal">
      <div class="eyebrow"><span></span> ZOSHA BEAUTY CLINIC · TAJRISH</div>
      <h1>جایی که زیبایی،<br><em>طبیعی‌تر دیده می‌شود.</em></h1>
      <p class="hero-lead">تجربه‌ای شخصی برای پوست، جوانسازی و زیبایی؛ با تمرکز بر نتیجه‌ای ظریف، هماهنگ با چهره و دور از اغراق.</p>
      <div class="hero-v5-actions">
        <a class="btn btn-primary" href="<?php echo esc_url(home_url('/booking/')); ?>"><span>رزرو مشاوره</span><b>↗</b></a>
        <a class="btn btn-ghost" href="<?php echo esc_url(home_url('/services/')); ?>">مشاهده خدمات</a>
      </div>
      <div class="hero-mini-grid">
        <div><span>01</span><strong>مشاوره شخصی</strong><small>انتخاب مسیر درمان براساس نیاز واقعی شما</small></div>
        <div><span>02</span><strong>نتیجه طبیعی</strong><small>تعادل، ظرافت و حفظ هویت چهره</small></div>
      </div>
    </div>
    <div class="hero-v5-visual reveal delay-1">
      <div class="hero-frame main-frame"><?php if($hero): ?><img src="<?php echo esc_url($hero); ?>" alt="درمان تخصصی پوست" fetchpriority="high" decoding="async"><?php endif; ?><span class="frame-tag">SKIN · BEAUTY · CARE</span></div>
      <div class="hero-frame floating-frame"><?php if($skin): ?><img src="<?php echo esc_url($skin); ?>" alt="مراقبت تخصصی پوست"><?php endif; ?></div>
      <div class="hero-seal"><span>زوشا</span><small>کلینیک زیبایی و پوست</small></div>
      <div class="hero-note"><i></i><p>مجتمع تندیس<br><strong>تجریش، تهران</strong></p></div>
    </div>
  </div>
  <div class="shell hero-ribbon">
    <span>فست‌لیفت</span><i></i><span>هایفوتراپی</span><i></i><span>لیزر</span><i></i><span>بوتاکس و فیلر</span><i></i><span>PRP</span><i></i><span>فیشال تخصصی</span>
  </div>
</section>

<section class="about-signature section-v5">
  <div class="shell signature-grid">
    <div class="signature-side reveal">
      <span class="section-label">01 · نگاه زوشا</span>
      <div class="signature-photo"><?php if($interior): ?><img src="<?php echo esc_url($interior); ?>" alt="فضای کلینیک زوشا" loading="lazy"><?php endif; ?><div class="photo-badge">ZOSHA<br><small>TAJRISH</small></div></div>
    </div>
    <div class="signature-copy reveal delay-1">
      <span class="mini-title">A DIFFERENT APPROACH</span>
      <h2>لوکس بودن، یعنی<br><em>همه‌چیز سر جای خودش باشد.</em></h2>
      <p>از انتخاب درمان تا فضای مراجعه، همه‌چیز باید منظم، آرام و دقیق باشد. در زوشا، هدف فقط انجام یک خدمت نیست؛ ساختن تجربه‌ای است که از اولین گفت‌وگو تا نتیجه نهایی حس حرفه‌ای بودن را منتقل کند.</p>
      <div class="signature-points">
        <div><b>01</b><span>ارزیابی و مشاوره قبل از انتخاب درمان</span></div>
        <div><b>02</b><span>توجه به تناسب چهره و کیفیت پوست</span></div>
        <div><b>03</b><span>طراحی مسیر مراقبت متناسب با هر فرد</span></div>
      </div>
      <a class="text-link" href="<?php echo esc_url(home_url('/about/')); ?>">بیشتر درباره زوشا <span>←</span></a>
    </div>
  </div>
</section>

<section class="services-showcase section-v5">
  <div class="shell">
    <div class="v5-head reveal">
      <div><span class="section-label">02 · خدمات منتخب</span><h2>برای هر نیاز،<br><em>یک مسیر دقیق.</em></h2></div>
      <p>خدمات زوشا با تمرکز بر جوانسازی، مراقبت پوستی و درمان‌های زیبایی طراحی شده‌اند؛ با اولویت دادن به نتیجه طبیعی و تجربه آرام مراجعه.</p>
    </div>
    <div class="service-cards-v5">
      <article class="service-card-v5 service-big reveal">
        <a href="<?php echo esc_url(home_url('/services/')); ?>">
          <div class="service-photo"><?php if($detail): ?><img src="<?php echo esc_url($detail); ?>" alt="فست لیفت و جوانسازی" loading="lazy"><?php endif; ?><span class="service-index">01</span></div>
          <div class="service-meta"><div><small>REJUVENATION</small><h3>فست‌لیفت و جوانسازی</h3></div><b>↗</b></div>
        </a>
      </article>
      <article class="service-card-v5 reveal delay-1">
        <a href="<?php echo esc_url(home_url('/services/')); ?>"><div class="service-photo"><?php if($laser): ?><img src="<?php echo esc_url($laser); ?>" alt="لیزر و هایفو" loading="lazy"><?php endif; ?><span class="service-index">02</span></div><div class="service-meta"><div><small>TECHNOLOGY</small><h3>لیزر و هایفوتراپی</h3></div><b>↗</b></div></a>
      </article>
      <article class="service-card-v5 reveal">
        <a href="<?php echo esc_url(home_url('/services/')); ?>"><div class="service-photo"><?php if($skin): ?><img src="<?php echo esc_url($skin); ?>" alt="فیشال و مراقبت پوست" loading="lazy"><?php endif; ?><span class="service-index">03</span></div><div class="service-meta"><div><small>SKIN CARE</small><h3>فیشال و مراقبت پوست</h3></div><b>↗</b></div></a>
      </article>
      <article class="service-card-v5 service-accent reveal delay-1">
        <a href="<?php echo esc_url(home_url('/services/')); ?>">
          <div class="accent-pattern"><span></span><span></span><span></span></div>
          <small>INJECTABLES</small><h3>بوتاکس، فیلر<br>و فرم‌دهی چهره</h3><p>برای ایجاد تغییرات ظریف و هماهنگ با ساختار صورت.</p><b>مشاهده همه خدمات ←</b>
        </a>
      </article>
    </div>
  </div>
</section>

<section class="experience-banner section-v5">
  <div class="shell">
    <div class="experience-card reveal">
      <?php if($interior): ?><img src="<?php echo esc_url($interior); ?>" alt="فضای کلینیک زوشا" loading="lazy"><?php endif; ?>
      <div class="experience-overlay"></div>
      <div class="experience-copy"><span>03 · تجربه زوشا</span><h2>فضایی که قبل از درمان،<br>آرامت می‌کند.</h2><p>فضای مراجعه، بخشی از کیفیت خدمات است. زوشا در محدوده تجریش، با تمرکز روی آرامش، نظم و حریم شخصی طراحی شده است.</p><a class="btn btn-light" href="<?php echo esc_url(home_url('/contact/')); ?>">مشاهده آدرس و تماس</a></div>
      <div class="experience-chip"><strong>ZOSHA</strong><span>TAJRISH · TANDIS</span></div>
    </div>
  </div>
</section>

<section class="journey section-v5">
  <div class="shell journey-grid">
    <div class="journey-title reveal"><span class="section-label">04 · مسیر مراجعه</span><h2>یک تجربه حرفه‌ای،<br><em>قدم‌به‌قدم.</em></h2><p>از تصمیم اولیه تا پیگیری بعد از درمان، مسیر مراجعه باید واضح و بدون سردرگمی باشد.</p></div>
    <div class="journey-steps">
      <div class="journey-step reveal"><span>01</span><div><h3>مشاوره و شناخت نیاز</h3><p>گفت‌وگو درباره نتیجه‌ای که می‌خواهید و بررسی شرایط پوست و چهره.</p></div><b>↙</b></div>
      <div class="journey-step reveal"><span>02</span><div><h3>طراحی مسیر درمان</h3><p>انتخاب روش مناسب با توضیح شفاف درباره مراحل و مراقبت‌های موردنیاز.</p></div><b>↙</b></div>
      <div class="journey-step reveal"><span>03</span><div><h3>اجرا و پیگیری</h3><p>انجام درمان و توجه به مراقبت‌های بعدی برای رسیدن به نتیجه بهتر.</p></div><b>↙</b></div>
    </div>
  </div>
</section>

<section class="gallery-v5 section-v5">
  <div class="shell">
    <div class="v5-head reveal"><div><span class="section-label">05 · گالری</span><h2>زیبایی در<br><em>جزئیات است.</em></h2></div><a class="text-link" target="_blank" rel="noopener" href="<?php echo esc_url(zosha_instagram()); ?>">مشاهده اینستاگرام <span>↗</span></a></div>
    <div class="gallery-stack">
      <?php foreach($gallery as $i=>$img): if($i>4) break; ?>
      <figure class="g<?php echo (int)$i+1; ?> reveal<?php echo $i%2?' delay-1':''; ?>"><img src="<?php echo esc_url($img); ?>" alt="تصویر کلینیک و خدمات زوشا" loading="lazy"></figure>
      <?php endforeach; ?>
      <div class="gallery-quote reveal"><span>“</span><p>زیبایی وقتی لوکس به نظر می‌رسد که <strong>زیاد تلاش نکند دیده شود.</strong></p></div>
    </div>
  </div>
</section>

<section class="booking-panel-v5 section-v5">
  <div class="shell booking-shell">
    <div class="booking-art reveal"><div class="booking-ring r1"></div><div class="booking-ring r2"></div><div class="booking-ring r3"></div><span>Z</span></div>
    <div class="booking-copy-v5 reveal delay-1"><span class="section-label light">06 · رزرو مشاوره</span><h2>اولین قدم را<br><em>ساده بردار.</em></h2><p>اگر برای انتخاب درمان مناسب مطمئن نیستید، از مشاوره شروع کنید. تیم زوشا برای انتخاب مسیر مناسب راهنمایی‌تان می‌کند.</p><div class="booking-buttons"><a class="btn btn-light solid" href="<?php echo esc_url(home_url('/booking/')); ?>">رزرو وقت آنلاین <b>↗</b></a><a class="booking-phone" href="tel:<?php echo esc_attr(zosha_phone()); ?>"><small>تماس مستقیم</small><strong><?php echo esc_html(zosha_phone()); ?></strong></a></div></div>
  </div>
</section>

<section class="faq-v5 section-v5">
  <div class="shell faq-grid">
    <div class="faq-title reveal"><span class="section-label">07 · سوالات متداول</span><h2>قبل از رزرو،<br><em>شاید این‌ها را بپرسی.</em></h2><p>پاسخ کوتاه به سوال‌هایی که معمولاً قبل از مراجعه مطرح می‌شوند.</p></div>
    <div class="faq-list">
      <div class="faq-item reveal"><button type="button"><span>برای انتخاب درمان مناسب از کجا شروع کنم؟</span><i>+</i></button><div class="faq-answer"><p>بهترین نقطه شروع، مشاوره است. در مشاوره شرایط پوست، فرم چهره و نتیجه موردنظر بررسی می‌شود و سپس مسیر مناسب پیشنهاد می‌شود.</p></div></div>
      <div class="faq-item reveal"><button type="button"><span>آیا می‌توانم قبل از مراجعه فقط مشاوره بگیرم؟</span><i>+</i></button><div class="faq-answer"><p>بله. هدف مشاوره این است که قبل از تصمیم‌گیری درباره درمان، اطلاعات کافی و مسیر روشن‌تری داشته باشید.</p></div></div>
      <div class="faq-item reveal"><button type="button"><span>چطور وقت رزرو کنم؟</span><i>+</i></button><div class="faq-answer"><p>از طریق صفحه رزرو آنلاین یا تماس مستقیم با کلینیک می‌توانید درخواست وقت ثبت کنید.</p></div></div>
    </div>
  </div>
</section>
<?php get_footer(); ?>
