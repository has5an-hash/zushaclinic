(()=>{const d=document,h=d.getElementById('siteHeader'),b=d.querySelector('.menu-button'),m=d.getElementById('mobileMenu');
const sc=()=>h?.classList.toggle('scrolled',scrollY>20); addEventListener('scroll',sc,{passive:true});sc();
b?.addEventListener('click',()=>{const o=b.getAttribute('aria-expanded')==='true';b.setAttribute('aria-expanded',String(!o));m?.classList.toggle('open',!o);d.body.classList.toggle('nav-open',!o)});
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.1});d.querySelectorAll('.reveal').forEach(x=>io.observe(x));
d.querySelectorAll('.faq-item button').forEach(btn=>btn.addEventListener('click',()=>{const item=btn.closest('.faq-item'),open=item.classList.contains('open');d.querySelectorAll('.faq-item.open').forEach(x=>x.classList.remove('open'));if(!open)item.classList.add('open')}));
const hero=d.querySelector('.hero-v5-visual');if(hero&&!matchMedia('(prefers-reduced-motion: reduce)').matches){addEventListener('pointermove',e=>{if(innerWidth<900)return;const x=(e.clientX/innerWidth-.5)*8,y=(e.clientY/innerHeight-.5)*8;hero.style.transform=`translate3d(${x}px,${y}px,0)`},{passive:true});}
})();
