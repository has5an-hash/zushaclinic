<?php get_header(); ?>
<section class="page-hero clean"><div class="shell"><span class="section-index">ZOSHA / JOURNAL</span><h1>دانستنی‌های زوشا</h1></div></section>
<section class="section"><div class="shell journal-grid"><?php if(have_posts()): while(have_posts()): the_post(); ?><article class="journal-card"><a href="<?php the_permalink(); ?>"><?php if(has_post_thumbnail()) the_post_thumbnail('large'); ?><span><?php echo esc_html(get_the_date()); ?></span><h2><?php the_title(); ?></h2><p><?php echo esc_html(wp_trim_words(get_the_excerpt(),18)); ?></p></a></article><?php endwhile; else: ?><div class="empty-state">مطلبی منتشر نشده است.</div><?php endif; ?></div></section>
<?php get_footer(); ?>
