<?php get_header(); ?>
<section class="page-hero clean"><div class="shell"><span class="section-index">ZOSHA</span><h1><?php the_title(); ?></h1></div></section>
<section class="section"><div class="shell prose"><?php while(have_posts()): the_post(); the_content(); endwhile; ?></div></section>
<?php get_footer(); ?>
